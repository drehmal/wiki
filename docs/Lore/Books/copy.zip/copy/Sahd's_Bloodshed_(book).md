*Three kingdoms ruled over the [island](Sahd_(Island) "wikilink"). To
the north, Eruis, the south, Asahn, and to the east, Durui. They battled
for centuries up until just a couple of centuries ago in the year 2803
where the conflicts were ended when a powerful arcanist by the name of
Vuhsan Dehre channeled all of Sahd's rage into a single catalyst,
breaking it into several pieces so it may never be rediscovered. Vuhsan
became loved, praised, and worshipped, and the people of
[Sahd](Sahd "wikilink") constructed a [great
palace](Emperor's_Estate "wikilink") atop a mountain overlooking the
island. Unfortunately, Vuhsan is dead now (due to natural causes - no
denizen of Sahd would dare stand in his way). The palace was passed down
through the generations, to Vuhsan's children's children, but it stands
dead and silent today due to unknown causes.*

[Category:Books](Category:Books "wikilink")