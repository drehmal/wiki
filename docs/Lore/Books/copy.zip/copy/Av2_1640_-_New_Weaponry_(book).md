This book can be found in [Sal'Mevir](Sal'Mevir "wikilink").

*Behold, the raw destructive power of the primal energy! This powered
railgun is able to strike foes from insane distances, creating an
explosion upon impact - an explosion that could easily level a city.
Maelihs stands no chance against us now.*

[Category:Books](Category:Books "wikilink")