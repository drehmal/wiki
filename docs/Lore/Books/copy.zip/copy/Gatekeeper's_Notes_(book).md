Gatekeeper's Notes can be found in [Mt.
Yavhlix](Mt._Yavhlix "wikilink").

*The door is shutting. It cannot leave. No matter what. I will gladly
die here so that thing cannot escape and wreck havoc.*

[Category:Books](Category:Books "wikilink")