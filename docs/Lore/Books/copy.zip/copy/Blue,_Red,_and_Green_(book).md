This book can be found in the [Exodus
Citadel.](The_Exodus_Citadel "wikilink")

*Avsohm has selected us, Blue Exodus, to be apart of the exclusive group
known as the "Big Three". We shall operate as a military and
construction organization, taking contracts from the government. The
other two members of this group are Red Dawn, a scientifically-focused
alchemical group, and Green Serpent, an organization focused around
commerce and trade.*

[Category:Books](Category:Books "wikilink")