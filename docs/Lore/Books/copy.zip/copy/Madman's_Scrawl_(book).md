Madman's Scrawl can be found in [Mt. Yavhlix](Mt._Yavhlix "wikilink").

*IT WILL TURN YOU INTO NOTHING BUT HOLES YOU WILL FEEL EMPTY YOU WILL
BECOME EMPTY YOU WILL BECOME NOTHING.*

[Category:Books](Category:Books "wikilink")