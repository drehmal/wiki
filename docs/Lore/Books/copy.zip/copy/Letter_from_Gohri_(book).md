Letter from Gohri can be found in [Mt. Yavhlix](Mt._Yavhlix "wikilink").

''Dear Thresa,

*My part of the plan is finished. Seeing as I am one of the few
permitted to work on the code for avSYS, it was relatively easy compared
to you and Vehmil's jobs.*

*As per your request, avSYS will now send individuals to both
[Sal'Mevir](Sal'Mevir "wikilink") and here at the [Exodus
Citadel](The_Exodus_Citadel "wikilink") to gain more info... assuming
the information within those locations is not lost to time.*

*I hope Vehmil's work is going well. Creating a whole temporal stasis
network is hard work, especially while under the watch of Avsohm.
Luckily, they trust me enough here where they won't look over my journal
or personal belongings. I suppose it's nice to work here then...
especially over that hellhole you have to deal with in Yavhlix.*

*I am afraid we will not get to meet before the end. If what you say is
true (why shouldn't I - you've never lied to me once in the decades
we've known each other), then... I think you know.* *How about, once
this is all over, we can meet again? Before it happens, I mean. Just
once your work is done. I don't know if they'll even let you leave
Yavhlix, but if they do, that would be quite nice.*

*We're on opposite sides of the continent, but we can meet somewhere.
Maybe in Fortahn? I don't know. We'll see, I guess.*

*Love,* *Gohri*

[Category:Books](Category:Books "wikilink")