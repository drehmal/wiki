This book can be found in the [Exodus
Citadel.](The_Exodus_Citadel "wikilink")

*Emperor Ifeihl has ordered the continuation of the construction on the
energy collection facility. Construction has all but halted since 1690
due to the death of Drehn Mal'sohm, but our current Emperor disagrees
with Mal'sohm's ways and thinks that this facility can be greatly
beneficial to the empire as a whole. Blue Exodus has been requested to
aid in the construction and defend the area from any attacks from
natives. The Emperor says that workers in the facility have seemingly
been going mad for an unknown reason, so if they pose a threat to
anyone, we are to kill on sight. This seems extreme but the madness does
not seem to go away and their minds are permenantly ruined.*

[Category:Books](Category:Books "wikilink")