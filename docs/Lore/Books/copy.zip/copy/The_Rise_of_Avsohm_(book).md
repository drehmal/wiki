This book can be found in [Drabyel](Drabyel "wikilink") in the [2.2
Demo](2.2_Demo "wikilink")

*The Chosen Kingdom of the Central Plains was undergoing tumultuous
times. Drehn Mal'sohm, heir to the throne, refused to inherit the crown
after his father's assassination. He saw the deep corruption of the
Kingdom, and deemed it unfit, as it clashed with Drehn's democratic
ideals. However, after thirteen years of insistence by the populace,
Drehn relented and ascended to the throne. His reign was characterized
by the heavy reform that transformed it into the Avsohmic Empire.
Drehn's primary goal was to unite the fractured Drehmari people together
to better prepare themselves for another conflict between deities.
Drehn's first major act was to move the capital from the corrupt Old
Drabyel to the more central city of Ihted. This was only temporary, as a
new capital was constructed from the ground up and named Av'Sal. The
city has since fallen to ruin, but those ruins contain many great and
powerful artifacts of the now fallen Avsohmic Empire.*

[Category:Books](Category:Books "wikilink")
[Category:Demo](Category:Demo "wikilink")