Av2 1820 - Patron's Pleas can be found in [Mt.
Yavhlix](Mt._Yavhlix "wikilink").

*I watched it kill Mirsu. My best friend. We got along so well, despite
everything.*

*I saw tiny holes appear in his body. Tiny, perfectly circular holes.
They pierced him, the ground, and the walls. They grew larger and
larger. Then he simply ceased to exist. How long until it finds me?
Please, oh merciful Virtuo, please save us...*

[Category:Books](Category:Books "wikilink")