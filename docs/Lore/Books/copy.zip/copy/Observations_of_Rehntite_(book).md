This book can be found in the Lost Cavern.

*It appears as if Rehntite can only be harvested with superheated lasers
powered by energy from the Yavhlix facility. We're increadibly luck to
have found this cavern and that energy source in only a handful of
years. The processing for Rehntite is even more complex that it cannot
be written in a single report.*

*We are still investigating the formation of this cavern and the
Rehntite within it. Our current hypothesis is divine intervention from
one of the Aspects - Koh is the most likely candidate, but Khive is also
worth mentioning because of the mineral's incredible high magical
tolerance.*

*I request that this report finds its way to the researches in
[Sal'Mevir](Sal'Mevir "wikilink"). They have a much more dedicated team
than we do here.*

[Category:Books](Category:Books "wikilink")