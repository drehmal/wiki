Av2 1816 - The Watchful can be found in [Mt.
Yavhlix](Mt._Yavhlix "wikilink").

*The Resonant Eye is a success. Truly the greatest creation of our time.
The amount of energy it requires is infathomable, but it's all worth
it.*

[Category:Books](Category:Books "wikilink")