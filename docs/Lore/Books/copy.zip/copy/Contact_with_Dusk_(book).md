This book can be found in [Ebonrun](Ebonrun "wikilink").

*Seems like the crew stationed on the eastern side of the Island of Dusk
has stopped responding to any of our letters or magic transmissions.*

*Guess I'll have to gather some guards and go see what happened. If I
remember correctly, the mining site is a bit inland? At the base of the
mountain. Unsure. We'll figure it out when we get there.*

[Category:Books](Category:Books "wikilink")