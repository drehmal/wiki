The Pawn is a book that can be found in [The Frozen Bite
Region](The_Frozen_Bite_Region "wikilink"), in the same house as
[Nihilist's Notes](Nihilist's_Notes "wikilink") and the book [Creature
of Nothing (books)](Creature_of_Nothing_(books) "wikilink")

*There is most definitely another pawn of this higher being. Avsohmic
documents are missing letters, words, paragraphs, entire pages. Ripped
out by something. But what, and for why? Why act in this way?*

*These three - the monster, the pawn, and the entity that controls
them - are working towards something sinister. And are extremely
powerful. What else could topple a super advanced, continent spanning
empire?*

[Category:Books](Category:Books "wikilink")