This book can be found in a [Faehrcyle](Faehrcyle "wikilink") Gatehouse
on the road from Highfall

***Day 16***

*   We found this old decrepit gatehouse which I assume was for keeping
Faehrcylian barbarians out of Highfall... not like the people of
Highfall aren't barbarians themselves. This will be a great resting
point before we continue our travels.*

***Day 20***

*   This cursed blizzard won't let up. We've been trapped in this old
ruin for days. Terthe, the geographical expert of the group, says that
Faehrcylian storms are infrequent and cannot be properly tracked. She
says she cannot predict when the clouds will clear. I just want to
continue, damnit. I want to find out what's out there. Maybe uncover
some ancient Avsohmic ruins? Who knows.*

***Day 27***

*   The blizzard has finally cleared and our food supplies are low, but
Terthe says that Faehrcyle is filled with game. As long as we're able to
make rudementary hunting tools, we'll be fine. Furthnehn, the youngest
of the group, is beginning to doubt the mission. He wants to go back
home to Mossfield where it's safer and not freezing cold. Poor kid. If
only he understood how unexplored the vast snowy wastes are. Who knows
what we could find? We could be rich!*

[Category:Books](Category:Books "wikilink")