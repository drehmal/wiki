Madman's Notes can be found in [Mt. Yavhlix](Mt._Yavhlix "wikilink").

*I hear the voices of a dead god who wants freedom from Nothing.*

*I hear the voices of a dead god who wants freedom from Nothing.*

*I hear the voices of a dead god who wants freedom from Nothing.*

*They were taken by a higher being.*

[Category:Books](Category:Books "wikilink")