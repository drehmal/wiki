This book can be found in the [Emperor's
Estate](Emperor's_Estate "wikilink").

*I've done it! The spell worked. The outlaws will be forever bound to
this place, defending the fragment til the end of time. A fitting end
for them, seeing as they confined us to this place for the last few
months.*

[Category:Books](Category:Books "wikilink")