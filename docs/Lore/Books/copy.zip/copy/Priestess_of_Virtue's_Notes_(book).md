This book can be found in the Parish of Virtuo in
[Highfall](Highfall "wikilink").

*I'm sick and tired of this day-by-day worship of Virtuo, the goddess
who has abandoned us. My ancestors refused to worship her for a reason,
and a good reason it was. In the north, Tethlaen worship is far more
common, but in Highfall, they are blinded by a false hope of peace and
prosperity, despite there being none since the dawn of the realm.*

*They always tell me that I'll be executed for my words against the
city's faith, but I do not care. They are insane fanatics. They tell me
that Tethlaen is dead, fell off the face of the realm. I don't believe
it. Why would a deity die in such a simple manner? They must be hiding
out, or they wish not to engage in Drehmari affairs, given how simple
minded we can be.*

*Maybe, sometime in the future, I can rebuild the old Chapel of
Tethlaen. But that won't happen as long as our current ruler is in
charge.*

[Category:Books](Category:Books "wikilink")