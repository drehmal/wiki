This book can be found in the [Emperor's
Estate](Emperor's_Estate "wikilink").

*Father's been his time in his studying tower lately. It's quite
dangerous outside so I understand why - the bandits have proven a
formidable force and several troops from the city have died already.*

[Category:Books](Category:Books "wikilink")