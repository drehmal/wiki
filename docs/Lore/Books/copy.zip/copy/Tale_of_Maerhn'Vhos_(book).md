*Ah, Maehrn'Vhos! The great wall of the west, constructed by an empire
long forgotten, only within the deepest pages of the oldest libraries!
Great Tharhan, the predecessor to the weak Tharxax, made the great wall
to fend off invaders into their vast, fertile land! Their first
challenger, the ancient Casain Empire, failed to pass this impenetrable
barrier! Their second challenger, the Kingdom of Western Merijool, could
not even approach the battered plains before it! With our own
enhancements, our own reinforcements, we will bring justice to the
greatest wall in the realm! All will cower before us, all who wish to
travel the old western roads!*

[Category:Books](Category:Books "wikilink")