This book can be found in [Highfall](Highfall "wikilink").

*During a trip to the coast of Akhlo'Rohma, we took a slight detour to
go sightseeing and maybe grab some refreshments from a local tavern.
But, one of our mules ran off the path with some of our supplies, so we
had to chase after it.*

*We didn't find the fella, but we found a cavern... no ordinary cavern,
however It had six orbs of light floating above small quartz pillars
outside its maw. Were these Primal Catalysts? The energy capacitors used
by the Avsohmic Empire millenia ago?*

*We unfortunately did not have the tools to safely carry these Catalysts
and we needed to head back anyway because our mule, Jemf, had some
important things on him that we really needed.*

*I plan on returning there, so I have the directions written down and
memorized for the future. Travel west along the great river that begins
at the Veruhkt Plateau, cutting through Akhlo'Rohma. On the northern
side of the river, where the white flowers grow, are gray peaks that
protect Akhlo'Rohma from the blizzards of Faehrcyle. Right before the
river meets the ocean are two valleys that touch the gray mountains. The
valley with the colored cliffs on its eastern side is the one with the
cave, at the base of the mountains.*

[Category:Books](Category:Books "wikilink")