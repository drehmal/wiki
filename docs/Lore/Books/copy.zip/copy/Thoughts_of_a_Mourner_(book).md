*I swear to Torahn itself, I will dig up as much of this Virtuo-forsaken
wasteland as I can.*

*She's burried here somewhere. I know it.*

[Category:Books](Category:Books "wikilink")