I've discovered I'm the last living citizen of Sal'Anyr. My work as a
thief has come in handy - sneaking around the Maelmari in the city is a
breeze, albeit a dangerous one. But, today, I saw a large obsidian-black
airship dock to the military complex... I had to go investigate. I snuck
into the base and overheard a conversation through the vents. I've
written it down in hopes I can bring it to the resistance fighters. I
don't know who the individuals are, but I'll be numbering them based off
of their voices.

1 - "Lord Maelihs, Ahlmor is within sight and has been for months! Why
not attack it now? There is no reason to delay western domination with
silly games."

2 - "Agreed! Your hatred for Virtuo and her followers is just, but it
clouds your judgement. I mean this with no disrespect my radiance."

3 - "What is the purpose for such a heavily coordinated attack?"

4 - "...They, the...Drehmari, are negligible fodder. They mean nothing
should they pledge allegiance against myself. I have an equal, whom you
know as Virtuo. She enforces her own will here and now I'm in the west,
far from her own domain. It is of no delight to me or any of you. It is
of great annoyance to me that she would dare attempt to halt the
expansion of my domain while hers is vast and uncontested in the east."

1 - " So you would delay your inevitable domination of the west because
you are jealous and bitter of Virtuo? That is the demeanor of a child!"

5 - " Stop the insubordination this instant, Jihn. Remember who you are
speaking to."

4 - "The Drehmari, the weak and insignificant, are if course propitious
to regain the land they stole from me. There is no greater approach than
this to destroy their morale for many millenia."

2 - "What of Drehmal? What will it think of this?"

4 - "If Drehmal does not care for what Avsohm did to Yavhlix, if Drehmal
does not care of the scarring of Mt. Ebonfire, and if it does not care
for the destruction of its people, then what will the unhindered
desolation of the Heartwood matter to it?"

6 - "Those examples are nothing compared to the genocide and
displacement of thousands of Drehmari, along with the destruction of
thousands of miles of land!"

4 - "It is of no concern to me. Those Drehmari are far from my reach,
nor do I care for the well being of Virtuo's domain. I only wish to see
the destruction of her firmament and the debilitation of the Drehmari
hope."

7 - "This is reckless and absurd."

8 - "My radiance, it seems you are not willing to change your mind on
the subject. Care to give specifics, then we can further debate?"

4 - "The Twinrock River would be the northern margin of the
desolation...reaching to Vir's...Straight. We shall unleash true
devastation, and witness the full extent of the Mother's capabilities."

I believe that was Maehlihs? There's no way a deity would be here in the
city. I need to leave. I'll prepare for my journey tomorrow.

[Category:Books](Category:Books "wikilink")