Scholar's Diary can be found in [Mount
Yavhlix](Mount_Yavhlix "wikilink").

*To think we found it... the source of everything, of nothing, of all
magic, of all material substances. With it, we can power Avsohm for
millions of years, and create untold technological wonders. But - as
they always say - everything has a consequence. I wonder if this will.*

[Category:Books](Category:Books "wikilink")