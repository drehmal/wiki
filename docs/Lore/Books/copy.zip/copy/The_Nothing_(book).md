The Nothing can be found in [Mt. Yavhlix](Mt._Yavhlix "wikilink").

*Seems the Eye has finally deciphered what lies beyond the veil. It took
a great deal of power - enough to fuel thousands of our weapons. The
results are fascinating, but we are unsure of how to interpret them.
Looks like that beyond the portal is still within our realm, still
within a veil, its "influence" if you will. We cannot see beyond it, but
the Eye can. It revealed with its holographic display, casting light
across the room, a beautiful diorama of space, nebula, colors...
stars... everything. At the center of this image was a great eye-shaped
cloud of yellow, orange, and purple clouds, surrounded by stars and
streaks of purple waves across the cosmos. The Eye then zooms onto a
single star and shows Drehmal; our realm. The question is: How reliable
is this information? We cannot see this vista with our own eyes, but the
eye should be able to. And what does this even mean?*

*We must conduct more research.*

[Category:Books](Category:Books "wikilink")