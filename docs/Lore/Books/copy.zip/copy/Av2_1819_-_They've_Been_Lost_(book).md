Av2 1819 - They've Been Lost can be found in [Mt.
Yavhlix](Mt._Yavhlix "wikilink").

*Theru's been taken. I don't know by what, but her mind is no longer
present. It's clear that she has some purpose, but... not her own. Her
eyes glow a faint yellow now. She tried to kill me, so they threw her
down the pit. She managed to crawl back up, half alive, legs broken, and
to the portal.*

*Then she just stood there.*

*She only attacked when people got close to the portal.*

*Something has corrupted this place.*

[Category:Books](Category:Books "wikilink")