This book can be found in a building in [Dusps](Dusps "wikilink").

*During the time of Avsohm, a mass murderer known as the Lake Man struck
fear into the hearts of the Drehmari. When he was captured, emperor
Zorhis Ifeihl ordered the construction of a vast underground network of
cells and tombs. Here, Avsohm would imprison and bury its greatest
criminals.*

*Unfortunately, due to frequent expeditions from both magical institutes
and the Order of Insohm, the Crypts grew unstable and collapsed in on
themselves. All that remains are a few buried entrances that lead to
nothing but rubble. The most well-kept of these is said to be northwest
of here, along the coast, hidden among the cliffs.*

*The Crypts were a fascinating places of wisdom and learning that were
unfortunately lost to time. Let it serve as a reminder that some
knowledge has dire consequences.*



[Category:Books](Category:Books "wikilink")