Av2 1820 - Gate's Closed can be found in [Mt.
Yavhlix](Mt._Yavhlix "wikilink").

*I shut the gate. I thought I did it. I thought I had saved the world
from this... thing.*

*But it didn't care. It swallowed itself whole and disappeared.*

*I think I'm the only one left. I'm afraid it will come back for me.*

[Category:Books](Category:Books "wikilink")