This book can be found in the [Exodus
Citadel.](The_Exodus_Citadel "wikilink")

*Dear Gohri,*

*What we've found down here is... I cannot even begin to describe it. I
wish not to burden you with the knowledge of this discovery, but,
perhaps in our future meeting we can discuss it. I know you've talked
about wanting to die alongside me, so... but I'd hate to live with the
knowledge that I doomed you. But I suppose it is necessary for our
project.*

*I think we'll call it the Primal Meltdown Plan... or something along
those lines. I really hope I'm wrong with my hypothesis, because this
whole thing is mortifying.*

*Vehmil is in fact done with his work. He contracted a few workers to
create the temporal stasis chamber at the Primal Caverns - why he chose
that place is beyond me, to be honest. But apparently, it works.*

*We just need to find some volunteers to get their memories wiped and
sent to the chamber. A few people in my circle know of the plan and
might be willing to volunteer.*

*Glad to hear your work on avSYS has gone well. I'm sure the officers at
the Exodus Citadel are quite lax with the whole thing - nobody is taking
the Mythbreaker Protocols seriously, unfortunately.*

*As for your meeting request... maybe, hopefully. I wish to see you
again.*

*Sincerely,*

*Thresa*

[Category:Books](Category:Books "wikilink")