Found in the Burnt Palace in [Hellcrags](Hellcrags_Region "wikilink")

*Lord Maelihs has turned soft. Weak. He shows no devotion to what we've
made over the millenia.*

*An opportunity has presented itself. Virtuo has gone dormant and
Drehmal continues to slumber. Instead of seizing the moment and taking
action, invading the continent once more, Mael decides to become
reclusive on Lo'Dahr.*

*It is up to us now. The remaining generals and lieutenants will take
charge and grow the domain of chaos to its greatest heights.*

[Category:Books](Category:Books "wikilink")