Av2 1632 - Incredible! can be found in
[Sal'Mevir](Sal'Mevir "wikilink").

*I cannot believe it! I simply can't! This newly discovered energy is
unlike anything else. Finally, something that will push the limits of
rehntite. Who knows what feats of engineering we can accomplish with
this breakthrough. The problem is, it's scarce. We'll need to dig deeper
into the mountain to discover its true source.*

[Category:Books](Category:Books "wikilink")