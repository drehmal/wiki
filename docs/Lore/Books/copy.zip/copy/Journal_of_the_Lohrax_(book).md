Found in a hallowed stump of a large tree in the northern part of the
[Spearhead Forest](Spearhead_Forest_Region "wikilink") region

*Yeah, I killed that Tide Queen!*

[Category:Books](Category:Books "wikilink")