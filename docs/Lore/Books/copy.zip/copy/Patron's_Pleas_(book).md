Patron's Pleas can be found in [Mt. Yavhlix](Mt._Yavhlix "wikilink").

*Oh merciful Virtuo, save me! Protect me from this thing! It'll swallow
me whole! It turned them all to nothing!*

[Category:Books](Category:Books "wikilink")