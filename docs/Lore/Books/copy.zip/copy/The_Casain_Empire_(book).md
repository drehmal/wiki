This book can be found in the [Athrah](Athrah "wikilink") library.

*The city of Athrah was founded sometime around Av2 1189 along the
northern edges of the Redsteps. It was centered around the northern
shores of Lake Athrah. A fierce warrior from the Zarha tribe of Southern
Casai, Athrah Zarha, envisioned a grand kingdom that spanned across the
Casain peninsula. The city of Athrah was the first step towards that
goal.*

*After some time, the tribes that were not apart of Athrah's growing
kingdom were denied trade with the kingdom unless they joined. After
that, most, if not all of Casai joined the kingdom, forming the Casain
Empire in Av2 1255. Unfortunately, Athrah Zarha had died in battle less
than a year after the uniting of the peninsula because of the unruly
barbarians in the northern reaches of Casai.*

*The kingdom's first major war was with the tribes of Western Merijool
in Av2 1445. This conflict became known as the Zephyr War, as it was
primarily fought for control over the plains south of Zephyr Sound.
Merijool proved victorious and claimed the plains for themselves. Since
the conclusion of the war, there has been uneasy tension between the two
nations (until Avsohm forced them to unite under their flag). A few
minor skirmishes have broken out along their borders since then, but
nothing severe enough to start another war. After the loss of the
plains, Casai looked south in search for more fertile farmland.
Lahu'Nozur was a fertile land, under control of the Tharhan Empire.
Tharhan had significant military power and held the area in a
stranglehold. Thus, Casai looked further south to the inhospitable
Golden Sands (now known as Anyr'Nogur). The Tharhan Empire saw no value
in that land, but Casai did, and so they took it without conflict. The
western shores of the Sands touched the warm water of the Sea of Mael
and were filled with coral reefs. Casai adapted quickly and became
primarily a fishing nation. In this time, Casai grew economically and
militarily, strengthening their borders and trading with far off empires
such as Ancehl and the Chosen Kingdom. This was often regarded as the
peak of the Casain Empire.*

*However, the Casain empire saw another opportuniry for power: Mt.
Ebonfire and its caldera. This was a Tharhan-controlled volcanic region
that was recently discovered to be filled to the brim with valuable
resources. With their accumulated military power, Casai declared war on
Tharhan over control of Ebonfire in Av2 1472.*

*What Casai failed to consider in this declaration was the immense
disadvantage they had. For one, this would make the only two nations
they bordered their enemies, as they already has great tensions with
Merijool. Second, they would have to transport troops from their primary
post near Athrah all the way south, across steep cliffs and mountains
into the Ebonfire caldera. Third, the Tharhans already had military
camps set up around Ebonfire for this exact situation.*

*The Ebonfire war was over before it began, and Casai lost. They had
only taken the worthless territory at the western edges of the mountain.
The war had destroyed their economy and military, marking the end of the
Casain Golden Age and the beginning of great turmoil within the nation.
The government in Athrah began focusing primarily on the peoples in the
Casain Peninsula, and those in the Golden Sands became disconnected.
Eventually, a small civil war was fought in Av2 1534 between those north
of Ebonfire and those south of it. The people located in the Golden
Sands split off from Casai, forming their own nation, the Golden
Kingdom.*

[Category:Books](Category:Books "wikilink")