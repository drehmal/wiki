This book can be found in [Tharxax City.](Tharxax_City "wikilink")

*The longer I spend here in Tharxax the more I question Maelihs. I
thought that Virtuo had a strong grasp on these places and forced the
people to face utter perfection, without looking at their own inner
flaws. But... these people are so much happier here than in the Carmine,
just south of here. If this city is supposedly a horrible place to live,
I wonder what other Drehmari settlements are like?*

*The Generals have forced me to put strict laws on those in Tharxax but
I always twist them to be more lenient. I truly pity these people. They
throw rocks and stones at me, they fear me, they hate me. I understand
why. I just wish it wasn't so.*

*I'm only here for so much longer til the Generals send me back to the
Carmine and replace me with another. They said I'll get a promotion.
Does that mean moving further into Mael's sanctum? Will I finally get to
see his fabled Burnt Palace?*

*I'm not sure if I want to.*

[Category:Books](Category:Books "wikilink")