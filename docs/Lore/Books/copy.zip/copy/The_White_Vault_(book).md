This book can be found in [Athrah.](Athrah "wikilink")

*Here in Casai, they try their damndest to make sure nobody enters that
old vault off the western coast. Apparently it contains some forbidden
knowledge, houses a monster... the old founder of Insohm went insane in
there for some reason. Who knows. I'd love to check it out one day but
apparently its sealed tight. Assumedly by Insohm so nobody would enter.
Quite odd that so many ancient Avsohmic structures were rediscovered by
Insohm, then forcibly closed off.*

*Their fates are similar when you think about it. Avsohm, most of their
government simply vanished one day. Insohm, their capitol also just...
vanished, without a trace. So strange too. Right by Mossfield, one of
the great cities of the Third Avihm. No eyewitness accounts, no direct
evidence, nothing. Just gone.*

[Category:Books](Category:Books "wikilink")