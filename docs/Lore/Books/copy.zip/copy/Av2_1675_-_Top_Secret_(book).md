This book can be found in [Sal'Mevir](Sal'Mevir "wikilink").

*The Avsohmic High Court has recently made the punishment for revealing
the Yavhlix construction project even more severe. A representative came
here and said that if any public knowledge was traced back to us, we
would face an eternity in temporal stasis.*

*I wonder why they want to keep it so secret. I understand wanting to
keep the energy to yourselves but I think the fact that we have so much
energy is common knowledge now. Hell, nearly everyone knows about
Yavhlix and how that's where the energy comes from. It's just so few
people outside of the construction workers have been inside there. I've
heard rumors of people going insane in there, but... they're just
rumors, right? I understand that this primal energy stuff is incredibly
volatile and dangerous, yet Avsohm must be taking precautions against
that, right?*

*It just doesn't make sense to me. There has to be something else going
on in that mountain.*

[Category:Books](Category:Books "wikilink")