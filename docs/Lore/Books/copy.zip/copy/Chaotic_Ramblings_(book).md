This book can be found in [Tharxax City](Tharxax_City "wikilink").

*My mother always told me that a good way to destress was to write down
all your thoughts personally, so... here I go, finally. Love you mom.*

*What's the point of all this? What's the point in being forced under a
harsh contract from some chaotic deity? Why would Maelihs need resources
from some old, outdated Insohmic-era city? I look out my window over to
the South and see those stark white cliffs and wonder what goes on
beyond those. The Lands of Chaos. What do they think of us over there?
What do they even use these resources for? Are they prosperous like the
delegate says? So many questions that I cannot stop thinking about.*

*I wish I could leave. Travellers are allowed to come and go but no
civilians are allowed to exit. It's all just... baffling. Truly
baffling.*

*I just wish Insohm never fell. They were great leaders. They had flaws,
sure, but they binded together all Drehmari better than any empire or
union before it. People heap praise on the ancient Avsohm, but... how
great were they, truly? Weren't there rumors of unethical practices
towards the end of their reign? I don't know. I don't like to think much
about them. Something about Avsohm puts me off and scares me.*

*I want my wife back. I miss her dearly. She managed to escape the city
without us, and... I don't know why. Did she even love us? Or was she
forced to leave on her own? She always talked about wanting to visit
Fort Nimahj, up to the north... looking over the largest river in the
realm, wondering what lies within the great swamp... I wonder if she
went there.*

*Maybe I should try to join her.*

[Category:Books](Category:Books "wikilink")