Emperor Anyr really is insane, huh? Never should have cast my vote for
him. Total sihf'mihk.

Why did he move here, to all places? Leaving the council to do all his
work for him. Just wants to wage war against Maelihs. An unwinnable
fight. I don't care how capable the Avsohmic military is, we would be
going up against a god.

I enjoyed my life in this city til he came around and turned it into a
military stronghold. It was a beautiful, spiritual site, made by the
ancient Casain settlers. I greatly enjoyed immersing myself in their
exotic culture and even planned on travelling north to Casai one day.
But no. Of course not. Now citizens are forbidden from leaving the city
for safety.

Kehf'ml toth Anyr.

[Category:Books](Category:Books "wikilink")