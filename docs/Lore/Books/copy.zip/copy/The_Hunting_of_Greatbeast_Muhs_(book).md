This book can be found in one of the buildings in
[Gozak](Gozak "wikilink").

*It is Av2 1583, and it is on this year that Greatbeast Muhs met his
fate. Muhs, one of the Aspects created before the Second Avihm, is the
father of all beasts within Drehmal. With that title, Father of BEasts,
comes certain hatreds and worships. Some worship the Wyrm - particularly
the people of [Heartwood](The_Heartwood_Region "wikilink"), the Gozaki.
Others hate the Wyrm, for he created ferocious monstrosities that have
caused many a Drehmari to meet a grisly fate. The Hunting Party is on
the side of hatred. They believe that by slaying Greatbeast Muhs they
shall not only end the scourge of murderous beasts, but also inherit his
enormous party. The Hunting Party is wise and powerful - highly skilled
individuals with a mighty Virmari amongst them. Greatbeast Muhs was a
god, but even gods can die. The party entered Muhs' den, the enormous
cavern along with Heartwood's western shore. Here they used powerful
runic devices to ensnare Muhs and nullify his powers. Still, Muhs proved
an incredibly formidable force, as a Wyrm. The Hunting Party emerged
victorious. The worshippers of Greatbeast Muhs mourned, hosting an
enormous funeral ceremony, one of the largest in history. The Hunting
PArty was subject to a hunt themselves and were killed be swathes of
angry mobs. The sole survivor of the Party was convicted of deicide and
sentenced to life in prison within the depths of Ihted, the Avsohmic
capital at the time. May we remember the repercussions of the Hunting
Party's goals and the impact it has had on the people of the Heartwood.*

[Category:Books](Category:Books "wikilink")