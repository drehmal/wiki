Av2 1621 - Notes on Survey Drones is found in
[Sal'Mevir](Sal'Mevir "wikilink").

*Survey drones - a marvel of engineering! Truly Avsohm's greatest
accomplishment yet. These Catalysts, made of pure rehnite, are beyond
our comprehension. What are the limits of its power? We know for certain
that drones are not its limit...*

[Category:Books](Category:Books "wikilink")