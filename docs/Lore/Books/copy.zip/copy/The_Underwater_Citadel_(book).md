This book can be found in the [Exodus
Citadel.](The_Exodus_Citadel "wikilink")

*Truly a feat of engineering, the Exodus Citadel is. Deep underwater
under Lake Nimahj, protected from the outside world and attacks from
Maelihs, hidden in the black void of water. I wonder if we should
continue constructing our bases and facilities underwater.*

[Category:Books](Category:Books "wikilink")