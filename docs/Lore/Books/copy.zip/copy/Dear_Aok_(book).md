This book can be found in one of the entrances to the [Moonlight
Sanctum](The_Moonlight_Sanctum "wikilink").

*Do you think the Theocracy will accept me? Hopefully so... I've come
this far, all the way from Mossfield, to enter the cult and become a
true necromancer...*

*Tell me, Aok, what compells you to write to me with these mysterious
letters? Did you cheat death as the legends say? Aok, First of the Dead,
the greatest necromancer to ever live? Of course! Of course. That would
only make sense, wouldn't it, Aok? How could someone as powerful as you,
with the ability to transcend the fabric that protects us from the voice
of space, simply die to some measly mercenaries from the First Avihm?
You must be proud, Aok. Proud of what I've done. Soon, I shall join you
in the ranks as master necromancer... under you, obviously. I would
never be able to reach such magnificence...*

*\*This page is covered in blood\**

*To Aok, First of the Dead, Last of the Living!*

[Category:Books](Category:Books "wikilink")