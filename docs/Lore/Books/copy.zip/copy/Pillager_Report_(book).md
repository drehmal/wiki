This book can be found in a chest in one of the buildings in
[Gozak](Gozak "wikilink").

*I've received reports of pillagers from the [Verdant
Labyrinth](The_Verdant_Labyrinth_Region "wikilink") moving into the old
ruined castle on the black mountain northeast of here. Apparently its
quite the formidable force. We'll have to assemble a squad of guard to
take them out or persuade them to leave.*

*I wonder why they've moved here. The group in the Labyrinth is
practically a small army - they have a stranglehold on the area and
plenty of resources. They're and extremely formidable force, but I don't
see why they would expand to that old abandoned castle? Maybe they're
looking for something. I've head rumors about that mountain hiding
something within it, but they're just that - rumors.*

[Category:Books](Category:Books "wikilink")