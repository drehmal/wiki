Av2 1617 - City of Wisdom can be found in
[Sal'Mevir](Sal'Mevir "wikilink").

*The founding of this facility has done wonders for the Avsohmic Empire.
A collaboration of our greatest minds, discovering the wonders of the
realm, and what may lie beyond.*

*I hope to bring on more arcanists and scholars to see what they can
contribute.*

[Category:Books](Category:Books "wikilink")