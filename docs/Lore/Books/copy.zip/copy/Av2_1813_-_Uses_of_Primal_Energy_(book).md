This book can be found in the [Exodus
Citadel.](The_Exodus_Citadel "wikilink")

*The source discovered deep within the primary energy collection
facility has granted us near unlimited amounts of Primal Energy, which
has bolstered our technological capabilities. With this newfound power,
we can perform magical actions that only the deities could do.*

*Storing this powerful energy is difficult, however. Luckily, we have
access to Rehntite, an incredibly durable mineral with a nigh infinite
amount of potentia, allowing the storage of Primal Energy. With
Rehntite, we are able to make Primal Catalysts which store and relay
energy.*

*These catalysts are quite volatile and cannot touch any solid surface
without risks, so they are placed on magnetic pillars which allow them
to float. Despite their volatility, they can last for an extremely long
time, predicted to be several millenia.*

[Category:Books](Category:Books "wikilink")