Av2 1631 - New Energy Source? is found in
[Sal'Mevir](Sal'Mevir "wikilink").

*We initially thought that the the energy source we detected almost 90
years ago was a fluke, a false alarm. We believed that the energy there
was far too low for it to have any use. We may be wrong. A sample was
taken from the mountain from a small (unauthorized) mining crew. This
sample... ...is far beyond what we thought the mountain could hold. We
will have to send more survey drones immediately.*

[Category:Books](Category:Books "wikilink")