This book can be found in [Mt. Yavhlix](Mt._Yavhlix "wikilink").

*At long last - the Eye has decoded what lies in the center of that
eye-shaped nebula. Unfortunately, due to how extremely dense the primal
energy there is (also an amount hundreds of trillion times greater than
the weapon we discovered), the image is incredibly blurry and full of
static.*

*It suggests some sort of... hall? Pillars, arches, a throne - fit for a
king. At the center of it all. At the center of everything.*

*I... do not know. This is beyond anything we can theorize. What does
this mean?*

*Is it some projection?*

*A fragment of our own realm? Is it Lo'Dahr? Is it the birthplace of
Drehmal? Could it even be where Khive created our magic? Could it be
where Khive is? Perhaps its some part of the First Avihm. Hell, it might
as well be the throne of Drehn Mal'Sohm himself, who knows! I don't
think we'll be able to find anything else that points to it, or helps us
figure out exactly what this room is.*

*Seems that it's really drained the Eye, moreso than usual. I guess its
seen too much.*

[Category:Books](Category:Books "wikilink")