This book is found at a Homesick Tergei's small camp north of the North
Tharxax tower.

*Day 247*

*I greatly miss my home. Mohta was such a wonderful place. My family
loved me and I ran a thriving business. But I had to leave... and I need
to come to terms with that. I cannot return no matter what.*

[Category:Books](Category:Books "wikilink")