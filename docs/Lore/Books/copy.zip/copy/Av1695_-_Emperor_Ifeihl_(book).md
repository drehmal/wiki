This book can be found in [Sal'Mevir](Sal'Mevir "wikilink").

*Ifeihl will be the end to this great empire. I know what he wants. He
just wants power. He's going to resume the construction project and go
after Maelihs, I swear. This technology will be the end of us all. I
rejoiced when I heard that the project was halted. Everyone here tells
me I'm just overreacting, I'm superstitious, and I'm too traditional.
They don't understand the full capabilities of this energy.*

*Whatever left the energy in that mountain would not be happy to know
that we're stealing its power.*

[Category:Books](Category:Books "wikilink")