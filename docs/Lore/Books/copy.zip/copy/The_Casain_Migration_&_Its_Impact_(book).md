This book can be found in a building in [Dusps](Dusps "wikilink").

*[Casai,](Casai_Region "wikilink") a land far to the west, across the
[Gulf of Drehmal](Gulf_of_Drehmal_Region "wikilink") and beyond the
autumnal [Merijool Peninsula](Merijool_Region "wikilink"), faced with a
great crisis at the dawn of the Third Avihm when the Avsohmic Empire
fell. Maelihs cam to conquer everything from Lorahn'Kahl to Merijool.
The Casain, while faithful and caring of their homeland, were planing an
exodus before Maelihs could wreck havoc on their towns and cities. Many
denied that Maelihs would be able to make his way all the way North to
Casai, but those though were put to rest when the city stronghold of
Sal'Anyr, at the heart of [Anyr'Nogur](Anyr'Nogur_Region "wikilink"),
perched atop high cliffs, fell within a day. At this moment, Casai began
a great migration to the East. They spread across the land, but most
have here - [Akhlo'Rohma](Akhlo'Rohma_Region "wikilink"). Unfortunately
for them, the fall of Avsohm mean a new government rose, the Dominion of
Ancehl. Ancehl was known for its corruption and its people for
xenophobia. They accused the Casain as cursed peoples, who would bring
the [Frostfang
Catastrophe](Av2_1647_-_Frostfang_Catastrophe_(book) "wikilink")*
[(2)](The_Frostfang_Catastrophe_(book) "wikilink") *to them. There were
many decades of hatred and fighting until it came to a conclusion in the
Dohval Civil War. The Dominion fell and in its place rose a new kingdom,
the Kingdom of Dusps, which would be fair and kind to its peoples.*

\(2\) is added to allow a second link and was not part of the original
text

[Category:Books](Category:Books "wikilink")