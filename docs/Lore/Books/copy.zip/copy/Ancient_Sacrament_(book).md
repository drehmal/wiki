This book can be found in a small structure right off of one of the
paths in [Lorahn'Kahl](Lorahn'Kahl_Region "wikilink").

*O, silnar-tuo Lorahn, creator of time,*

*O, terhmis-tuo Loruhn, home of drakes,*

*O, mari-tuo Lo'Dahr, throne of the divine,*

*Call upon your power, your bright tohsima, bring life to the unliving,
in the name of Aok the First Dead!*

[Category:Books](Category:Books "wikilink")