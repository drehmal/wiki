This book can be found in an abandoned mineshaft between [Nimahj
Swamp](Nimahj_Swamp_Region "wikilink") and South Tharxax tower.

*Dear Nimbog Mining Crew,*

*   I hope the operation is going smoothly. I know that the swamps can
be treacherous this time of year. Cautionary measures against flooding
are absolutely necessary here, especially during Dahrohma.*

*Remember, the ore deposit you are looking for should be exactly 18
meters below sea level. We need it extracted before Maelmaklah. The
processors here at Tharxax are growing impatient.*

*Sincerely,*

*Hosim Arghelin*

[Category:Books](Category:Books "wikilink")