Av2 1820 - Evacuation Orders can be found in [Mt.
Yavhlix](Mt._Yavhlix "wikilink").

*To all of my subordinates: We are to begin evacuation tomorrow morning.
We detected massive fluctuations in energy coming from the portal. The
Resonant Eye has started malfunctioning as well. All contact has been
lost with those operating within the portal. We have no explanation for
these events, but I assure you everything will be fine. The evacuations
are simply a cautionary measure - one that hasn't happened in years, but
still, the point stands.*

*Thank you for your time.*

[Category:Books](Category:Books "wikilink")