Av2 1818 - Crawled Out can be found in [Mt.
Yavhlix](Mt._Yavhlix "wikilink").

*A... thing? Clambered out of the portal. Very odd looking... almost
alien, I'd say. It had a Drehmari-esque body but was smooth and slimey,
covered in something that resembled black tar. It had no mouth, and
simply moved its hands and sent... messages... directly to our heads.*

*"You must leave. You must leave now."*

*"He has noticed. He is displeased. Leave before He takes you."*

*"You cannot kill Him. Nobody can. Nothing can."*

*"You cannot know of Him. I will die soon. He will kill me."*

[Category:Books](Category:Books "wikilink")