Av2 1690 - Construction Halted can be found in
[Sal'Mevir](Sal'Mevir "wikilink").

*The ongoing mining and construction project  in Faehrcyle has been
halted due to growing political instability. This means our supply of
primal energy is being cut short - it is still incredibly plentiful, but
we must be more mindful when using it. I hope a future emperor continues
the project.*

[Category:Books](Category:Books "wikilink")