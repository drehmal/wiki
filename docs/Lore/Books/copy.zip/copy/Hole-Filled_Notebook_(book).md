Hole-Filled Notebook can be found in [Mt.
Yavhlix](Mt._Yavhlix "wikilink").

*What is more terrifying than Nothing?* *It's a monster, a beast, a
slithering horror of red and black tentacles bound together by a bloody
ribcage. At its head, an empty hole, deep as the cosmic abyss. It's maw
ensues terror, and delivers it swiftly. What could we call such a
hideous miscreation of sin?*

[Category:Books](Category:Books "wikilink")