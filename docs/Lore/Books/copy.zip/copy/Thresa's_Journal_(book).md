Thresa's Journal can be found in [Mt. Yavhlix.](Mt._Yavhlix "wikilink")

''13th of Torahnlahu

*Why must they not take this seriously? Our dimwitted commander does not
realize the gravity of this situation. What the Resonant Eye has found
is so unfathomable, so beyond our control, meddling with it will be our
end.*

*20th of Torahnlahu*

*After further research, it seems that there is in fact an entity which
controls this space. That controls the things we've found. It's coming
to kill us, like that thing which crawled out of the portal. We have
knowledge of it, and we will be punished for it.*

*That idiot commander thinks that we'll be able to take it. Sihf'mihk.
There's no way. Absolutely none. There is no hope in this situation.*

*4th of Torahnsohma*

*It's been a couple weeks now since our discovery and I've contacted my
friends Gohri and Vehmil to help. Avsohm has begun construction of
protocols in case this goes wrong, but these are not enough - they
assume that the empire will survive.*

*We have some volunteers for the project as well, including ourselves.*

*The temporal stasis chamber Vehmil constructed at the Primal Caverns
will wipe the memories of participants and release them a couple years
later - just to be safe. Using the activation towers already constructed
for the Mythbreaker Protocols, the participant will be sent to the
presumably destroyed Sal'Mevir and Exodus Citadel to gain knowledge of
what's going on - as their memories will be wiped. This is all thanks to
Gohri and her work with recoding avSYS.*

*Hopefully, by the time the participants are awakened, the entity will
be gone and they will be free to shut down the collection of primal
energy, should it continue afterwards. They can fix whatever went wrong,
or try and stop it. I'm not really sure what would happen at this point,
but maybe Avsohm can continue after this, with the work we've done. All
that matters is we're hopeful. Hopeful for a better future.* *I guess it
was a good thing they kept information about Yavhlix secretive.*

[Category:Books](Category:Books "wikilink")