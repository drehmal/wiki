Worker's Diary can be found in [Mt. Yavhlix](Mt._Yavhlix "wikilink").

*How long until it finds me? How long? This is horrifying... this is
worse than death.*

[Category:Books](Category:Books "wikilink")