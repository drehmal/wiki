This book can be found in the [Emperor's
Estate](Emperor's_Estate "wikilink").

*Master's at it again. Talking about some "curse". "Curse the bandits,
curse the fiends - their children too." Now he's gone and locked himself
in the tower behind the Estate again.*

[Category:Books](Category:Books "wikilink")