This book can be found in [Drabyel](Drabyel "wikilink").

*The Chosen Kingdom of the Central Plains had only formed a few
centuries before, and it was ready for great change. Drehn Mal'sohm, son
of the current ruler of the kingdom, Rohdirk Mal'sohm, refused to
inherit the crown after his father's assassination. Drehn did not wish
to to do so because he wished for a democratic kingdom, but it's current
state did not allow that because of heavy influence from powerful
nobles. After 13 years of the people begging for Drehn to take his
father's place, he finally accepted, and became the Chosen Kingdom's
ruler in Av2 1535. He then reformed the Kingdom into the Avsohmic
Kingdom, meaning "One Group", united together. Drehn's primary goal was
to unite the fractured Drehmari people together to better prepare
themselves for another Deity War. Drehn's first major act was to move
the capital from the corrupted Old Drabyel (which was destroyed in the
Third Avihm by Maelihs' Chaos Outriders), to the more central city of
Ihted. Later, a new capital was constructed named Av'sal, meaning "One
City". The City has since been lost to time by landslides due to its
location on the mountain slopes west of New Drabyel. Avsohm's diplomatic
success was surprisingly succesful, and the first kingdom to agree to
unite with them were the Tharhan Empire which had encompassed the
present-day Tharxax Plains and Ebony Veldt. Unfortunately, with the
death of Drehn Mal'sohm to a devastating plague in Av2 1687, the
Avsohmic Empire slowly declined in stability and strong rulers. Drehn's
successor was Emperor Zorhis Ifeihl. Ifeihl was popular among the
populace at first, but quickly fell out of favor when their management
of the ongoing war with the Tri-Moon Theocracy went south, resulting in
the deaths of thousands at the hands of the undead. Ifeihl's successor
would be Avsohm's last emperor, Uffhiel Anyr. Emperor Anyr was loved by
the people of Avsohm because of his great military prowess. The growing
threat of an invasion from Mael's Sanctum allowed Emperor Anyr to
conduct military tactics that would be seen as outrageous today. For
example, he transferred himself to the city of Sal'Anyr west of the
Tharxax Plains. Avsohm met its end after a mysterious event resulted in
the disappearance of many of the empire's military and higher-ups. Mael
took this moment of chaos to invade, and was successfuly able to conquer
all of the West. Many began to forget the legacy of Avsohm now that
Maelihs controlled most of the empire's territory. Now, it is but a
fleeting memory.*

[Category:Books](Category:Books "wikilink")