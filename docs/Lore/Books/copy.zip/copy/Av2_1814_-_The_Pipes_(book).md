Av2 1814 - The Pipes can be found in [Mt.
Yavhlix](Mt._Yavhlix "wikilink").

*I cannot leave. This place is cursed beyond belief. I don't even know
why we're here. All I know is that I'm supposed to keep up maintenance
on the piping. I dont even know what's in the pipes! I just want to
leave, I want to go home...*

[Category:Books](Category:Books "wikilink")