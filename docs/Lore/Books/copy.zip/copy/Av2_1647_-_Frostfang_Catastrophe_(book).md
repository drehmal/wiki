Av2 1647 - Frostfang Catastrophe can be found in
[Sal'Mevir](Sal'Mevir "wikilink").

*An ecological disaster has struck. With the ongoing skirmish between
the Frostfang Tribes and Avsohm over the land surrounding Mt. Yavhlix,
tensions have been high. Homli Tasgahn, a member of the Tribes, used his
unlimited potentia to push back Avsohmic forces... but something went
wrong. Homli managed to create an intense blizzard that increased in
size and severity until it grew out of control. That blizzard has
enveloped the entire North. Faehrcyle, the Gulf, Merijool, and Casai
have all been affected by this catastrophe. The land surrounding the
mining operation at Mt. Yavhlix has become uninhabitable. While this
sounds bad, this means we can continue the operation without
interference. We have the technology to withstand the cold.*

[Category:Books](Category:Books "wikilink")