Avsohmic Hi-Tech Glider can be found in the highest tower of
[Sal'Mevir](Sal'Mevir "wikilink").

*My creation may not be up to par with other technology developed here,
such as temporal cages or weapons of mass destruction, but it's use and
importance is possibly greater than the others. I don't know what it's
use could mean, but Blue Exodus paid me to do it, so here I am. Some
things to know about the glider:*

*1. HIGHLY FLAMMABLE. Do not use with any explosive materials or items.*

*2. Incompatible with certain magics, specifically water-based ones.*

[Category:Books](Category:Books "wikilink")