This book can be found in [Ebonrun](Ebonrun "wikilink").

*The workers came back today from the mineshaft on the southern face of
Mt. Ebonfire. Apparently, poisonous spiders have decided to make their
home there. So the miners ran out, dropping their tools along the way...
and apparently left their most valuable one behind. Ugh... getting a
replacement of one of those might be a challenge.*

[Category:Books](Category:Books "wikilink")