This book can be found in The Grihm Troupe,
[Highfall](Highfall "wikilink")

*\*The book is filled with unfamiliar runes, vastly different from those
used for magic. You make out what seems like a moth, or some sort of
strange worm?\**

[Category:Books](Category:Books "wikilink")