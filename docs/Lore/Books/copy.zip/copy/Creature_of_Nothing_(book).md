This book can be located in the same house as [Nihilist's
Notes](Nihilist's_Notes "wikilink") in [The Frozen Bite
Region](The_Frozen_Bite_Region "wikilink")

*After what I saw beneath the Tidal Palace, I knew it was over. What I
found was what ended Avsohm. I thought it was only myth - holes, endless
holes, consuming and encompassing all.*

*I had to write down everything I found before I went mad. This...
creature, I'll call it the Gaping Hole. It kills with its glare, turning
anything it wishes into Nothing. It invaded Avsohm's most secretive
places and destroyed them from the inside out, killing any and all that
witnessed it.*

*The monster is clearly driven by some higher power, but what? Its
simple minded and seems to go wherever it pleases, but its gone now.
Otherwise we'd all be dead.*

[Category:Books](Category:Books "wikilink")