Wisewoman's Journal can be found at the top of a mountain in the
northmost area of the [Merijool region.](Merijool_Region "wikilink")

*Av2 1820, 15th of Drehmaklah*

*I knew it. That cursed mountain never should have been dug into. Avsohm
is in the wrong to have ignored the words of the locals and wisemen of
the realm. Here I am, atop Mt. Mekta, far away from their operation, and
I see a great storm approaching. The clouds, advancing faster than any
other. Streaks of primal, yellow light being cast down upon the world.*

*Avsohm has angered something and thus we all will be punished for it.*

[Category:Books](Category:Books "wikilink")