This book can be found in the [Emperor's
Estate](Emperor's_Estate "wikilink").

*I've received word of a group of bandits approaching the estate. They
wish to find a fragment of Frenzy. I'll be calling on the city to send
troops over to defend the estate. We cannot let a fragment fall into the
hands of Villainy.*

[Category:Books](Category:Books "wikilink")