This book can be found in a shelter on the northeast island of
[Casai.](Casai_Region "wikilink")

*I'm almost ready to set sail towards the Island of Dusk. Over 1000
meters north... quite the treacherous journey. Wonder what I'll find
there? If I understand correctly, the only people who dare traverse the
northern sea to the islands are miners and researchers, not tourists.
Count me as one of the lucky few.*

[Category:Books](Category:Books "wikilink")