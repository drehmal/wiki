Commander's Message can be found in [Mt.
Yavhlix](Mt._Yavhlix "wikilink").

*To my superiors: The portal has been closed, and the gate as well. The
abberation seems gone for now, but... who knows.*

[Category:Books](Category:Books "wikilink")