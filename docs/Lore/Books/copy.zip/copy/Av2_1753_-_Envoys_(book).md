This book can be found in the [Black Jungle
Library](Black_Jungle_Library "wikilink").

*Our great king has decided that, in order to gain and advantage over
our rivals, is to try and gain land and join forces with the
civilization that taken root in the Black Jungle. We should send envoys
and see if they are willing to join forces. I have received word from
the envoys. They were slaughtered by an army coming from the "Tidal
Dynasty". Only one survived and made it back here to our outpost.
Apparently, the Dynasty's ruler, the Tide Queen, recalls our old history
where we sent prisoners to the mainland. She aims to "wipe us from
history". Find by me. I'd rather stay our of mainland conflicts of I'm
to be honest.*

[Category:Books](Category:Books "wikilink")