This book can be found in the Drabyel Bookstore



#### ***------DREHMAL------***

*   Drehmal (Dreh-mawl) is the creator of the new realm, the one made at
the dawn of the Second Avihm. They rest now, but their influence is
unthinkable, having the ability to reform the realm at will. They take
the appearance of a gargantuan white snake with great, tree-like antlers
and a dangling leafy beard. They represent neutrality, creation, and
balance. While they have not done as much as Maelihs and Virtuo
post-Av1, they are undoubtably the most powerful.*

#### ***------MAELIHS------***

*   Maelihs (Male-ehs or like 'malice') is the deity of chaos,
corruption, and conflict. They work towards pure and utter evil,
starting wars for the sake of war. Millions have died at his hand, with
his most notable crimes being those that have permanently scarred the
realm. Maelihs is extremely strong, both in combat and in the magical
arts. He appears as a giant, 30-foot tall man covered head-to-toe in
heavy metal armor. Curved horns sprout out the sides of his head and he
wields a greatsword made of red metal.*

#### ***------VIRTUO------***

*   Virtuo (Ver-chu-oh) is the deity of peace, purity, and perfection.
They work towards improving the realm for all, bringing prosperity to
the afflicted. Ever since the end of the Deity Wars (the great thousand
year battle between Maelihs and Virtuo that ended in Av2 1000), she has
brought nothing but good to the realm. Unfortunately, she went dormant
in Av3 978, marking the start of the Fourth Avihm. She appears as a
beautiful woman in a flowing blue gown, with purple hair and light pink
eyes.*

[Category:Books](Category:Books "wikilink")