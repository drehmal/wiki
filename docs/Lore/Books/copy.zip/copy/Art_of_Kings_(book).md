Found in ruins off the path west of the Primal Caverns in the [Capital
Valley](Capital_Valley_Region "wikilink") region

*...and so the old king of Casai, Iansal, became obsessed with art...
wanted nothing more than the walls painted in color and beauty.*

[Category:Books](Category:Books "wikilink")