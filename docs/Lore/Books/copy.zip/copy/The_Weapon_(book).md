The Weapon can be found in [Mt. Yavhlix](Mt._Yavhlix "wikilink").

*The Resonant Eye has created another image, or item, for us to
interpret. It's a strange polearm - a long shaft, littered with stars,
with a long yellow blade at the end made of what appears to be primal
energy. It seems to be perfect in every way - perfectly smooth, no
indents, no cracks, nothing. Even the blade, made of the most powerful,
volatile substance we know of, is perfectly stable - even if it contains
more primal energy we've ever used... times several million. The amount
of power this object radiates is immense and we have no clue who or what
it belongs to. Our commander has asked us to make a replica (a far, far
weaker one, obviously) and use it for testing. Once it has been
constructed and properly tested, the commander will take it and place it
under extremely high security. They won't tell us where, unfortunately.*

[Category:Books](Category:Books "wikilink")