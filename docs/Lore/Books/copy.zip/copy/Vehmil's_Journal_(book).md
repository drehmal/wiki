This book can be found in [Sal'Mevir.](Sal'Mevir "wikilink")

*The temporal stasis project is complete. I shall send word to Gohri and
Thresa immediately, though the two may be preoccupied with whatever
starcrossed Drehmari do.*

*I'm very grateful knowing that my work will help protect the realm
against what lies beyond. What Thresa tells us is harrowing, to say the
least. I wish not to confront it, but considering I have knowledge of
it, I am already doomed.*

[Category:Books](Category:Books "wikilink")