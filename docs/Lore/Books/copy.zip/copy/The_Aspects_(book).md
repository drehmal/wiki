This book can be found in the [Drabyel](Drabyel "wikilink") Bookstore.

*The Aspects are minor deities that assisted the Primal Tree in the
creation of the realm before Av2. They no longer have much influence
over the realm, as they wish not to interfere with it anymore. All of
them are reptilian in some way, most of them being great winged beasts.*

#### ***--GREATER ASPECTS--***

***Mystic Elder Khive**, Great Arcant Aspect. Khive turned magic into
something usable by other deities and mortals.*

***Land-Fall Drake Taihgel**, Great Land Aspect. Created the land and
continents.*

***Abyssal Elder Dahr**, Great Sea Aspect. Brought water to the realm
and made the oceans.*

***Star-Rise Drake Rihelma**, Great Sky Aspect. Created the skies, the
clouds, and most things above our heads.*

*
*

#### ***--LESSER ASPECTS--***

***Summit-Drake Nahyn**, Mountain Aspect. Child of Taihgel.*

***Wise Worm Koh**, Aspect of Stone. Child of Nahyn.*

***Noha of Meadows**, Aspect of Plains. Child of Taihgel. Deceased.*

***Lahrs**,* *the Ever-Flourish, Aspect of Growth. Child of Noha and
Vayniklah.*

***Water-Wyrm Dahroehl**, Aspect of Water. Child of Dahr.*

***Tempest Palaesida**, Aspect of Storms. Child of Dahr and Rihalae.
Deceased.*

***Zephyr Rihalae**, Aspect of Wind, Child of Rihelma.*

***Lai**, the Brightwyrm, Aspect of Warmth*

***Infernal Lailoehn**, Aspect of Fire. Child of Lai*

***Glacial Elder Loe**, Aspect of Cold*

***Loeleyhn**, the Avalanche, Aspect of Snow. Child of Loe.*

***Soul-Stealer Voynahla**, Aspect of Death. Deceased.*

***Life-Bringer Vayniklah**, Aspect of Life*

***Greatbeast Muhs**, Aspect of Beasts. Child of Vayniklah. Deceased.*

***Mari**, the Great Drehmari, Aspect of Man. Child of Vayniklah.*

***Abominate Maen**, Aspect of Hate. Child of Mari.*

***Kind Wyrm Moen**, Aspect of Love. Child of Mari.*

***Tethlaen**, the Ever Fear, Aspect of Fear. Child of Mari. Deceased.*

<references />

[Category:Books](Category:Books "wikilink")