This book can be found in the [Firteid](Firteid "wikilink") Libary.

*The Black Jungle; a lawless land, plunged into chaos after the fall of
the Empire of Vir, sought a ruler strong enough to bind together the
region. The Tide Queen, whose real name is unknown, seized this
opportunity to create the Tidal Dynasty and conquer all of the Jungle.
It was soon discovered that she held unlimited potentia. She would use
this ability to make herself immortal, immediately regenerating all
wounds and eradicating all of her own diseases. She quickly grew
paranoid of her own death, despite her natural advantages. The Dynasty
then established rigorous defensive measures and a totalitarian
dictatorship to further protect the Queen. This came with a massive
military which she used to expand the Dynasty's territory further. This
incited war with Gozak, which ended with the Dynasty controlling Gozak's
eastern coasts. Avsohm, nearing its peak, attempted to conquer the
Dynasty, but failed due to the steep mountains in the north and the
treacherous Black Jungle itself. The Queen then ordered a state of
isolation in Av2 1569. In the next two decades, the re-emergance of
Virtuo frightened the Queen, as she believed that it would threaten and
weaken her rule. She then declared herself a devout follower of the
Goddess of Purity. The Queen decides that the best way to keep her
position is to twist the public's view on Virtuo by greatly limiting who
is allowed to the Goddess' Kiln. The Queen commited many atrocities
during this time, the most notable being a mass genocide against those
that the Queen deemed too "impure" in Virtuo's eyes. Virtuo grew afraid
of acting out against the Dynasty because of the possibility of a great
war, resulting in more casualties than necessary. When Avsohm created
their survey drones, the Tide Queen ordered that they are to be
destroyed on sight, allowing her to continue her reign of terror. The
Tidal Dynasty would obviously suffer during early Av3, with the lack of
a central power in Avsohm, the destruction of the southern Heartwood,
and Mael's invasion of the Verdant Labyrinth. After this time, the
Queen's confidence grew tremendously, with her possibly being the
greatest swordfighter in Drehmal's history after centuries of training.
The Queen ordered the ending of their isolationist policy in the Av3 436
as she was finally confident in her ability to defend herself. In Av3
612, the Order of Insohm learned of the many atrocities commited by the
Tide Queen and her unfair, unjust rule over the Black Jungle. Hovadchear
Myrik assembled a team of mercenaries (whose names will not be
mentioned) to assassinate the Tide Queen. They were successful with the
aid of Virtuo and advanced combat techniques. With the Tide Queen gone,
the Order pushed in to improve relations with the Dynasty, but this of
course led to the Tidal War, the largest conflict the realm had seen
since the Dune Wars.*

[Category:Books](Category:Books "wikilink")