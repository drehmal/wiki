This book can be found in an Avsohmic Vault on an island off the west
coast of [Casai.](Casai_Region "wikilink")

*Emperor Ifeihl, in the wake of the recent censoring of all information
surrounding the Yavhlix facility, has ordered the construction of vaults
that will store said information to keep it exclusive to higher ranking
members of the Avsohmic government and certain organizations such as
Blue Exodus. These vaults will also store other pieces of knowledge that
are dangerous to the public, but the focus will be on the primary energy
collection facility beneath Mt. Yavhlix and the applications of Primal
Energy.*

[Category:Books](Category:Books "wikilink")